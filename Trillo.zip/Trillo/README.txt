Hello there, thanks for checking out my booking app.

I built this app as part of a course to practice SCSS. I did not create the design, but I did write all of the code myself, as I felt my skills with SCSS were at a point where I could code independently. 

Since this app uses SVG you will need to open a live development server in order to fully view it.

To see more of my work go to https://github.com/Guthlac

If you would like to contact me you can reach me at:

jordangscholes@gmail.com
07516319431